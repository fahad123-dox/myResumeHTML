let counterElement = document.getElementById("visit_counting_numbers");

function updateCounter(){
    fetch("https://9gxsw6cj3g.execute-api.ap-south-1.amazonaws.com/dev")
    .then(res => res.json())
    .then(data => {
        counterElement.innerHTML = data.count;
    })
    .catch(error => console.error('Error fetching the counter:', error));
}

updateCounter();
